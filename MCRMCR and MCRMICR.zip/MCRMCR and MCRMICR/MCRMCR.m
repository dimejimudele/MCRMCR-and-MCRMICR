%
function [MCRMCRFS,CMI_S]=MCRMCR(a,MI_C,C,maxFeature)
%% parameter
% a�� the data encludes class attribute
% MI:the matrix of mutual information,MI(x1,x2) means I(x1;x2)
% MI_C: MI_C(x1) means I(x1;C)
% CMI_C:the matrix of conditional mutual information,CMI(x1,x2) means I(x1;x2|C)
% C: the class attribute
% maxFeature: the maximum number of selected features
% beta: controal the weight of redundancy
[n,dim]=size(a);
if nargin<6
    maxFeature=dim;
end
H=zeros(dim,dim);
H=computeCMImatrix_4([a,C]);

CMI_S=zeros(dim,dim);
selected=zeros(1,dim);
MCRMCRFS=zeros(1,maxFeature);

fprintf('MCRMCR:select the first feature\n');

max_MI=0;
firstFeature=1;
for i=1:dim
    if MI_C(i)>max_MI
        max_MI=MI_C(i);
        firstFeature=i;
    end
end
MCRMCRFS(1)=firstFeature;
selected(firstFeature)=1;

H=H';
[p,q]=size(H);
for i=1:dim
    for j=1:dim
        CMI_S(i,j)=1000;
    end
end
for j=2:maxFeature
   
    maxInc=-inf;
    bestFeature=0;
    for m=1:dim
        if selected(m)
            continue;
        end
        S=MCRMCRFS(1:j-1);
        
        if j==2
            inc=min(H(m,S));
        else
            inc=min(H(m,S)-min(CMI_S(m,S)));  

        end
        
        if inc>maxInc
            maxInc=inc;
            bestFeature=m;
        end
    end
    MCRMCRFS(j)=bestFeature;
    selected(bestFeature)=1;
    CMI_S=CM_updateCMI_S(CMI_S, a, MCRMCRFS, bestFeature);

end

end
    
        
        
        
        
        
        
        
        
        
        
        
        