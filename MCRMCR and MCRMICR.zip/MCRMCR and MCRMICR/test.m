clear;clc;
addpath(genpath('MIToolbox'));
load('wine.mat');
data=wine(:,2:end);
C=wine(:,1);
data=normalize_max(data);
a=myQuantileDiscretize(data,5);
MI = getMI(a);
MI_C = getMI_C(a,C);
CMI_C = getCMI_C(a, C);

[m,n]=size(a);
if n>50
    k=50;
else
    k=n;
end

[MCRMCRFS]=MCRMCR(a,MI_C,C,k);
[MCRMICRFS]=MCRMICR(a,MI,MI_C,CMI_C,C,k,0.1);
[RelaxMRMRFS]=relaxMRMR(a, MI,MI_C, CMI_C, 2, k);

