
function [MCRMICRFS]=MCRMICR(a,MI,MI_C,CMI_C,C,maxFeature,beta)
%% parameter
% a�� the data encludes class attribute
% MI:the matrix of mutual information,MI(x1,x2) means I(x1;x2)
% MI_C: MI_C(x1) means I(x1;C)
% CMI_C:the matrix of conditional mutual information,CMI(x1,x2) means I(x1;x2|C)
% C: the class attribute
% maxFeature: the maximum number of selected features
% beta: controal the weight of redundancy
[n,dim]=size(a);
if nargin<6
    maxFeature=dim;
end
H=zeros(dim,dim);
H=computeCMImatrix_4([a,C]);

selected=zeros(1,dim);
MCRMICRFS=zeros(1,maxFeature);
fprintf('MCRMICR:select the first feature\n');
%%select the first feature with MI
max_MI=0;
firstFeature=1;
for i=1:dim
    if MI_C(i)>max_MI
        max_MI=MI_C(i);
        firstFeature=i;
    end
end
MCRMICRFS(1)=firstFeature;
selected(firstFeature)=1;

H=H';
[p,q]=size(H);
%%Forward search 
for j=2:maxFeature
    maxInc=-inf;
    bestFeature=0;
    for m=1:dim
        if selected(m)
            continue;
        end
        S=MCRMICRFS(1:j-1);
        if j==2
            inc=min(H(m,S));
            %H(m,x1)=I(xm;C|x1)
        else
            inc=min(H(m,S))-beta*min((MI(m,S)-CMI_C(m,S)));
            %MI(m,x1)-CMI_C(m,x1): I(xm;x1)-I(xm;x1|C)
        end;
        if inc>maxInc
            maxInc=inc;
            bestFeature=m; 
        end
    end
    MCRMICRFS(j)=bestFeature;
    selected(bestFeature)=1;
    
end
end
       