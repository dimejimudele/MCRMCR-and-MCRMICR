function CMI_S = CM_updateCMI_S(CMI_S, a, best_fs, addedFeature)
[n, dim] = size(CMI_S);
j = addedFeature;%
for m = 1:dim
    for i = best_fs
        if i == 0
            break;
        end
        if i == j
            continue;
        end
        CMI_S(m, j) = min(CMI_S(m, j),cmi(a(:,m),a(:,i),a(:,j)));
        CMI_S(m, i) = min(CMI_S(m, i),cmi(a(:,m),a(:,j),a(:,i)));

    end
end
end