//Nguyen X. Vinh, Jeffrey Chan, Simone Romano and James Bailey, "Effective Global Approaches for Mutual Information based Feature Selection". 
//To appear in Proceeedings of the 20th ACM SIGKDD Conference on Knowledge Discovery and Data Mining (KDD'14), August 24-27, New York City, 2014. 
// (C) 2014 Nguyen Xuan Vinh   
// Email: vinh.nguyen@unimelb.edu.au, vinh.nguyenx@gmail.com
// Mex code for computing the pairwise MI matrix between feature-feature and feature-class
// Last row of the data matrix is the class variable
        
#include "mex.h" /* Always include this */
#include <math.h>

int compare_feature_config(double *data,int nPa,int* Pa,int a,int posi, int posj);
double conditional_MI(double *data,int i, int j,int nPa,int *Pa, int n_state,int n_stateC);
void  Contingency(int Mem1,int Mem2,int n_state,int n_stateC);
double Mutu_Info(int **T, int n_state,int n_stateC);
void ClearT(int n_state,int n_stateC);			//clear the share contingency table

double getij(double* A, int nrows,int i,int j){return A[i + nrows*j];}
void setij(double* A, int nrows,int i,int j,double val){A[i + nrows*j]=val;}


//global variables
int** T=NULL;
int n_state=0;
int n_stateC=0;
int N=0;
int dim=0;
double* data=NULL;   


void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{

#define A_IN prhs[0]
#define B_OUT plhs[0]

double *B, *A;       
N = mxGetM(A_IN); /* Get the dimensions of A */
dim = mxGetN(A_IN);
//mexPrintf("dim=%d\n",dim);
B_OUT = mxCreateDoubleMatrix(dim, dim, mxREAL); /* Create the output matrix */

data = mxGetPr(A_IN);

B = mxGetPr(B_OUT); /* Get the pointer to the data of B */
//get number of state of the data
for(int i=0;i<N;i++){
	   for (int j=0;j<dim-1;j++){			
            if (n_state<data[i+N*j]) n_state=data[i+N*j];
        }
}

for(int i=0;i<N;i++){
    if (n_stateC<data[i+(dim-1)*N]) n_stateC=data[i+(dim-1)*N];
}

n_state++;  //Attention: buffer for state (C index starts from 0)
n_stateC++;

T=new int*[n_state];
if (n_stateC>n_state) for(int i=0;i<n_state;i++) T[i]=new int[n_stateC];
else for(int i=0;i<n_state;i++) T[i]=new int[n_state];

//compute MI and fill in B

int* Pa=new int[1];
for (int i = 0; i < dim-1; i++){ //no need to compute last rows, i.e. I(C,X_i)
    for(int j = i; j <dim; j++) 
    {
        double MI;
        if (j==dim-1) 
        {   

            MI=conditional_MI(data, i, j,0, Pa, n_state,n_stateC);//compute MI(Xi;C)
            //mexPrintf("i=%d,j=%d,MI=%lf\n",i,j,MI);
        }
        else 
        {
            MI=conditional_MI(data, i, j,0, Pa, n_state,n_state);
        }//compute MI(Xi;Xj)
        //printf(" MI=%f\t",MI);
        //setij(B,dim,i,j,MI);
        B[i+(dim)*j]=MI;
        
        //setij(B,dim,j,i,MI);
        B[j+(dim)*i]=MI;
    }
}


for(int i=0;i<n_state;i++) delete[] T[i];
delete T;

return;
}//end of main


// data[i][j] => data[i + nrows*j];
void Contingency(int a,int b,int n_state,int n_stateC){	
    for(int i=0;i<n_state;i++)
        for(int j=0;j<n_stateC;j++)
            T[i][j]=0;    
    //build table
	for(int i =0;i<N;i++){         
		 //T[data[i][a]][data[i][b]]++;  
        T[(int)data[i+N*a]][(int)data[i+N*b]]++;  
	}   
}

//compare a feature set configuration of node a at two position in the data: char type
int compare_feature_config(double *data,int nPa,int* Pa,int a,int posi, int posj){
	int	isSame=1;
	for (int i=0;i<nPa;i++){ //scan through the list of features        
		//if(data[posi][Pa[i]]!=data[posj][Pa[i]]){//check this feature value at posi & posj
        if(data[posi+N*Pa[i]]!=data[posj+N*Pa[i]]){//check this feature value at posi & posj
			return 0;
		}
	}
return isSame;
}

double Mutu_Info(int **T, int n_state,int n_stateC){  //get the mutual information from a contingency table
	//n_state: #rows n_stateC:#cols
    double MI=0;
	int *a = new int[n_state];
	int *b = new int[n_stateC];
	int N=0;

	for(int i=0;i<n_state;i++){ //row sum
		a[i]=0;
		for(int j=0;j<n_stateC;j++)
		{a[i]+=T[i][j];}
	}
    
	for(int i=0;i<n_stateC;i++){ //col sum
		b[i]=0;
		for(int j=0;j<n_state;j++)
		{b[i]+=T[j][i];}
	}

	for(int i=0;i<n_state;i++) {N+=a[i];}
    
	for(int i=0;i<n_state;i++){
		for(int j=0;j<n_stateC;j++){
			if(T[i][j]>0){
				MI+= T[i][j]*log(double(T[i][j])*N/a[i]/b[j])/log(double(2));
			}
		}
	}
	delete []a;
	delete []b;
   // mexPrintf("\nMI=%lf\n",MI/N);
	return MI/N;
}

void ClearT(int n_state,int n_stateC){
	for(int i=0;i<n_state;i++){
		for(int j=0;j<n_stateC;j++){
			T[i][j]=0;
		}
	}
}

//conditional MI between node a-> node b given other feature Pa
double conditional_MI(double *data,int a, int b,int nPa, int* Pa, int n_state,int n_stateC){
double MI=0;

if (nPa==0){ //no feature
     Contingency(a,b,n_state, n_stateC);
     /*
     for(int i=0;i<n_state;i++)
     {
         for(int j=0;j<n_stateC;j++)
         {
             mexPrintf("%d ",T[i][j]);
         }
         mexPrintf("\n");
     }*/
	 return Mutu_Info(T, n_state, n_stateC);
}
else {	//with some features?
	int  * scanned=new int[N];

	for(int i=0;i<N;i++){scanned[i]=0;}

	for(int i=0;i<N;i++){ //scan all rows of data
		if(scanned[i]==0){  //a new  combination of Pa found		
			scanned[i]=1;
			double count=1;
			ClearT(n_state, n_stateC);
			T[(int)data[i+N*a]][(int)data[i+N*b]]++;

			for(int j=i+1;j<N;j++){
				if(scanned[j]==0 && compare_feature_config(data,nPa,Pa,b,i,j)){
					scanned[j]=1;	 				
					T[(int)data[j+N*a]][(int)data[j+N*b]]++;
					count++;
				}
			}
			MI+=(count/N)*Mutu_Info(T,n_state, n_stateC);
		}
	}
	delete[] scanned;	
}

return MI;
}