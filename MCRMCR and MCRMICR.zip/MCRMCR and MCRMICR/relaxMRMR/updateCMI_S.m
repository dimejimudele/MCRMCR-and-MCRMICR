% Nguyen Xuan Vinh, Shuo Zhou, Jeffrey Chan, James Bailey, "Can High-Order Dependencies Improve Mutual Information based Feature Selection?",
% (C) 2015 Shuo Zhou   
% Email: zhous@student.unimelb.edu.au, zhous.se@gmail.com
% updateCMI_S update the sum of conditional mutual information between
% feature Xm and selected feature Xi with given a selected feature Xj
% sum(I(Xm; Xi | Xj))

function CMI_S = updateCMI_S(CMI_S, a, best_fs, addedFeature)
[n, dim] = size(CMI_S);
j = addedFeature;
for m = 1:dim
    for i = best_fs
        if i == 0
            break;
        end
        if i == j
            continue;
        end
        CMI_S(m, j) = CMI_S(m, j) + cmi(a(:,m),a(:,i),a(:,j));
        CMI_S(m, i) = CMI_S(m, i) + cmi(a(:,m),a(:,j),a(:,i));
    end
end
end