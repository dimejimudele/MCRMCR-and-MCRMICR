function CMI_m = getCMI_m(a, C)
[n dim] = size(a);
for i = 1:dim
    if mod(i, 100) == 0
        fprintf('filling CMI_C table %dth row\n', i);    
    end
    for j = 1:dim
        CMI_m(i,j) = cmi(a(:,i),C,a(:,j));
    end
end
end